
use mexc_rust_sdk::MexcClient;

#[test]
fn test_ping() {
    let client = MexcClient::new("api_key".to_string(), "api_secret".to_string());
    let result = client.ping();
    assert!(result.is_ok());
    println!("Ping: {}", result.unwrap());
}

#[test]
fn test_avg_price() {
    let client = MexcClient::new("api_key".to_string(), "api_secret".to_string());
    let result = client.avg_price("BTCUSDT");
    assert!(result.is_ok());
    println!("Avg Price: {}", result.unwrap());
}

#[test]
fn test_ticker_price() {
    let client = MexcClient::new("api_key".to_string(), "api_secret".to_string());
    let result = client.ticker_price(Some("BTCUSDT"));
    assert!(result.is_ok());
    println!("Ticker Price: {}", result.unwrap());
}
    