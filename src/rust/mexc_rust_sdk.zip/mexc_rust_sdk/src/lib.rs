
use pyo3::prelude::*;
use pyo3::types::PyDict;

pub struct MexcClient {
    api_key: String,
    api_secret: String,
}

impl MexcClient {
    pub fn new(api_key: String, api_secret: String) -> Self {
        Self { api_key, api_secret }
    }

    pub fn ping(&self) -> Result<String, String> {
        let gil = Python::acquire_gil();
        let py = gil.python();

        // Import Python SDK
        let mexc_sdk = py.import("mexc_sdk").map_err(|e| e.to_string())?;
        let spot_client = mexc_sdk
            .call_method1("Spot", (self.api_key.as_str(), self.api_secret.as_str()))
            .map_err(|e| e.to_string())?;
        let result = spot_client.call_method0("ping").map_err(|e| e.to_string())?;
        result.extract::<String>().map_err(|e| e.to_string())
    }

    pub fn avg_price(&self, symbol: &str) -> Result<String, String> {
        let gil = Python::acquire_gil();
        let py = gil.python();

        let mexc_sdk = py.import("mexc_sdk").map_err(|e| e.to_string())?;
        let spot_client = mexc_sdk
            .call_method1("Spot", (self.api_key.as_str(), self.api_secret.as_str()))
            .map_err(|e| e.to_string())?;
        let result = spot_client
            .call_method1("avgPrice", (symbol,))
            .map_err(|e| e.to_string())?;
        result.extract::<String>().map_err(|e| e.to_string())
    }

    pub fn ticker_price(&self, symbol: Option<&str>) -> Result<String, String> {
        let gil = Python::acquire_gil();
        let py = gil.python();

        let mexc_sdk = py.import("mexc_sdk").map_err(|e| e.to_string())?;
        let spot_client = mexc_sdk
            .call_method1("Spot", (self.api_key.as_str(), self.api_secret.as_str()))
            .map_err(|e| e.to_string())?;
        let result = if let Some(symbol) = symbol {
            spot_client.call_method1("tickerPrice", (symbol,))
        } else {
            spot_client.call_method0("tickerPrice")
        }
        .map_err(|e| e.to_string())?;
        result.extract::<String>().map_err(|e| e.to_string())
    }
}
    