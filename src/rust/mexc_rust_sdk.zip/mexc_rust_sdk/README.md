
# MEXC Rust SDK

This is a Rust SDK for interacting with the MEXC API, built on top of the official Python SDK. This library allows Rust developers to interact with the MEXC API seamlessly while using the existing Python SDK under the hood.

## Features

- Ping the server to check connectivity.
- Fetch average price for a symbol.
- Retrieve ticker price for a symbol.

## Installation

1. Ensure you have Python and the `mexc_sdk` Python package installed:
    ```bash
    pip install mexc_sdk
    ```

2. Add this library to your Rust project using the source code.

## Usage

### Initialization

Create a new `MexcClient` instance by passing your API key and API secret.

```rust
use mexc_rust_sdk::MexcClient;

let client = MexcClient::new("your_api_key".to_string(), "your_api_secret".to_string());
```

### Functions

#### `ping()`

Pings the MEXC server to check if it is reachable.

```rust
let result = client.ping();
match result {
    Ok(response) => println!("Ping successful: {}", response),
    Err(err) => println!("Ping failed: {}", err),
}
```

#### `avg_price(symbol: &str)`

Fetches the average price for a given trading pair (e.g., `BTCUSDT`).

```rust
let result = client.avg_price("BTCUSDT");
match result {
    Ok(price) => println!("Average Price: {}", price),
    Err(err) => println!("Error fetching average price: {}", err),
}
```

#### `ticker_price(symbol: Option<&str>)`

Fetches the current ticker price for a given symbol. If no symbol is provided, it retrieves prices for all symbols.

```rust
let result = client.ticker_price(Some("BTCUSDT"));
match result {
    Ok(price) => println!("Ticker Price: {}", price),
    Err(err) => println!("Error fetching ticker price: {}", err),
}
```

## Testing

Run the included tests to verify functionality:

```bash
cargo test
```

## Notes

- Ensure that Python is installed and accessible in your environment.
- Install the required Python SDK (`mexc_sdk`) before using this library.
- API keys are required for authenticated requests.

# @floor-licker November 2024
